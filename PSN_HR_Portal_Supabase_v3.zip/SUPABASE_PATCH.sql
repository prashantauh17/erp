-- PSN HR Portal - Supabase cloud state table
-- Run this ONCE in Supabase SQL Editor.

create table if not exists public.portal_state (
  state_key text primary key,
  data jsonb not null default '{}'::jsonb,
  updated_at timestamptz not null default now()
);

alter table public.portal_state enable row level security;

drop policy if exists "Portal state public read" on public.portal_state;
drop policy if exists "Portal state public insert" on public.portal_state;
drop policy if exists "Portal state public update" on public.portal_state;
drop policy if exists "Portal state public delete" on public.portal_state;

create policy "Portal state public read"
on public.portal_state for select
using (true);

create policy "Portal state public insert"
on public.portal_state for insert
with check (true);

create policy "Portal state public update"
on public.portal_state for update
using (true)
with check (true);

create policy "Portal state public delete"
on public.portal_state for delete
using (true);

-- Optional starter rows
insert into public.portal_state (state_key, data)
values
('candidate_onboarding','[]'::jsonb),
('candidate_masters','{}'::jsonb),
('employee_management','{}'::jsonb)
on conflict (state_key) do nothing;
