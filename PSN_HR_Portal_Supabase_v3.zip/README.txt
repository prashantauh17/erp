PSN HR Portal - Supabase Connected

STEP 1
Open Supabase > SQL Editor > New Query.
Paste SUPABASE_PATCH.sql and click Run.

STEP 2
Deploy index.html and employee-management.html together in the same Vercel project.

HOW IT WORKS
- Candidate Onboarding data saves to Supabase.
- Employee Management data saves to Supabase.
- Browser localStorage remains only as cache/fallback.
- When a candidate is marked Joined and an Employee Code is entered,
  the employee is automatically transferred to Employee Management.

SECURITY
- Current policies are open for initial testing.
- Add Supabase Auth + role-based RLS before production use.
